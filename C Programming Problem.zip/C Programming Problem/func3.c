extern int vm, v1, v2;
int v3 = 3;

func3()
{
    return printf("f3, vm=%d, v1=%d, v2=%d, v3=%d\n",vm,v1,v2,v3);
}
